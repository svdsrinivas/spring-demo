package com.mia.configserver.service;

import com.mia.configserver.entity.AgentGroup;
import com.mia.configserver.repository.AgentGroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ConfigService {
    private final static String REDIS_CACHE_VALUE = "myconfig";
    @Autowired
    AgentGroupRepository repository;

    @CachePut(value = REDIS_CACHE_VALUE, key = "#agentGroup.id")
    public AgentGroup saveAgentGroup(AgentGroup agentGroup){
        return this.repository.save(agentGroup);
    }

    @Cacheable(value = REDIS_CACHE_VALUE, key = "#id")
    public Optional<AgentGroup> findById(Integer id) {
        return this.repository.findById(id);
    }

    @CacheEvict(value = REDIS_CACHE_VALUE, key = "#id")
    public List<AgentGroup> delete(Integer id) {
        this.repository.deleteById(id);
        return this.repository.findAll();
    }
}
