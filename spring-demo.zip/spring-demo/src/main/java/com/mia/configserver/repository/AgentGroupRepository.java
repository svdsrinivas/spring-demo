package com.mia.configserver.repository;

import com.mia.configserver.entity.AgentGroup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentGroupRepository extends JpaRepository<AgentGroup, Integer> {
}
