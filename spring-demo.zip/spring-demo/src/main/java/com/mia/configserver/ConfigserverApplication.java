package com.mia.configserver;

import com.mia.configserver.entity.AgentGroup;
import com.mia.configserver.entity.Person;
import com.mia.configserver.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableCaching
public class ConfigserverApplication implements CommandLineRunner {

	@Autowired
	private ConfigService service;

	public static void main(String[] args) {

		SpringApplication.run(ConfigserverApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception{
		List<Person> personList = new ArrayList<>();

		Person person = new Person();
		person.setId(1);
		person.setFirstName("srinivas");
		person.setLastName("s");
		person.setUserName("vsett");
		personList.add(person);

		AgentGroup agentGroup = new AgentGroup();
		agentGroup.setId(111);
		agentGroup.setDescription("agent 1");
		agentGroup.setPersons(personList);

		this.service.saveAgentGroup(agentGroup);


	}



}
