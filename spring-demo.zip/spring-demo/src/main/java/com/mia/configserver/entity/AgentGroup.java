package com.mia.configserver.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "AgentGroup")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AgentGroup implements java.io.Serializable {
    @Id
    private Integer id;

    @Column(name = "description")
    private String description;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn( name = "pc_fid", referencedColumnName = "id")
    List<Person> persons = new ArrayList<>();
}
