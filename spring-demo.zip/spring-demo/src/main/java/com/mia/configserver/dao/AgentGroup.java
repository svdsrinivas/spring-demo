package com.mia.configserver.dao;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AgentGroup {
    private String dbId;
    private String description;
    List<Person> persons = new ArrayList<>();
}
